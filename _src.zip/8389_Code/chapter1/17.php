<?php

switch ($temperature) {

    case 50:
        echo "Let's stay home and write some code.\n";
        break;

    case 80:
        echo "Let's go to the beach\n";
        break;

    default:
        echo "Go to jail. Do not pass go.\n";
        break;
}

?>