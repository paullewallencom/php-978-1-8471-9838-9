<?php

// showing "one true brace" convention
class Otb
{
    // for metods as well
    public method doSomething()
    {
        // your clever and immensely important code goes here
        // ...
    }
}

?>