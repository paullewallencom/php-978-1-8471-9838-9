<refentry id="{@id}" > 
    <refnamediv> 
        <refname>Web Services Authentication Tutorial</refname> 
        <refpurpose>How to use the authentication web service to obtain
            a security token that will be required for subsequent
            web services requests.</refpurpose> 
    </refnamediv> 
    <refsynopsisdiv> 
        <author>
            Dirk Merkel
            <authorblurb>{@link mailto:dirk@waferthin.com Dirk Merkel}</authorblurb> 
        </author> 
    </refsynopsisdiv> 
    {@toc}
    <refsect1 id="{@id intro}">
        <title>Web Services Authentication Tutorial</title> 
        <para>Pay attention because this is how you will have to
            impplement authentication to access our web service ...</para> 
    </refsect1> 
</refentry>