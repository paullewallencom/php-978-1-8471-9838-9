<?php

interface Configurable
{
    public function setup();
    public function getSetting();
}

?>