<?php

// require global initializtion file that sets up environment
require_once 'private/includes/global_init.php';

// initializing controller for MVC architecture
$controller->dispatch();

?>