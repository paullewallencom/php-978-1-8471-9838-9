<?php

echo "Hello World!";

?>