<?php

// set the environment constant
define(ENVIRONMENT, 'Development');

// include error & logging configuration
require_once('php_error.php');

echo "Hello World!';

?>